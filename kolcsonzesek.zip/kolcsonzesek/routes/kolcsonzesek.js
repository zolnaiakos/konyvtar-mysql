import express from 'express'
import pool from '../data/database.js'

const router = express.Router();



router.get('/', async(req,res)=>{
    let sql = 'SELECT * FROM kolcsonzesek';
    

    if(req.query.aktiv === 'true'){
          sql = 'SELECT * FROM kolcsonzesek WHERE visszahozva=false'
      }

    const [kolcsonzesek] = await (pool.query)(sql);

    let konyvC = 'SELECT cim FROM konyvek'
    const [konyvcim] = await (pool.query)(konyvC);

    let olvasoN = 'SELECT nev FROM olvasok'
    const [olvasonev] = await (pool.query)(olvasoN);

    let plusz = kolcsonzesek.map(kolcsonzes => {
        const konyv = konyvcim.find(k => k.id === kolcsonzes.konyvek_id);
        const olvaso = olvasonev.find(o => o.id === kolcsonzes.olvasok_id);

        return{
        kolcsonzes,
        konyvcim : konyv?.cim,
        olvasonev: olvaso?.nev
    };
        
    })

       res.json(kolcsonzesek);
 
})


router.post('/', async(req,res)=>{
    const {konyvId,olvasoId} = req.body;

    const sql = 'INSERT INTO kolcsonzesek (konyvId,olvasoId,datum,visszahozva)'

    const [uj] = await (pool.query)(sql, konyvId, olvasoId)

    res.status(201).json(
        uj
    )
})

router.patch('/kolcsonzesek/:id/visszahoz', async(req,res) => {
    const id = req.params.id

    const sql = 'UPDATE kolcsonzesek SET visszahozva = true, visszahozasdatum=CURDATE() WHERE ID = ?'

    const [eredmeny] = await (pool.query)(sql,[id]);
})

export default router;