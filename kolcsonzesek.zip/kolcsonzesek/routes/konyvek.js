import express from 'expres'
import pool from '../data/database.js'

const router = express.router();

router.get('/elerheto', async =>{
    const sql = 'SELECT * FROM konyvek WHERE kolcsonzes = false'

    const [konyvek] =  pool.query(sql)

    res.json(konyvek)
})

export default router