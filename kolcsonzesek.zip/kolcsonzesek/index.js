import express from 'express'
import kolcsonzesRoutes from './routes/kolcsonzesek.js';
import konyvekRoutes from './routes/konyvek.js';


const app = express();
const port = 3000;



app.use('/kolcsonzesek', kolcsonzesRoutes);
app.use('/konyvek', konyvekRoutes);


app.listen(port,() => console.log(`Szerver fut: http://localhost:${port}`))